COUPON CODE BACKEND FIX
POPUP
CUSTOMER CARE PART
FIX META DATA OF PAGES
FIX BLOGS
account page address problem
account/profile  problem