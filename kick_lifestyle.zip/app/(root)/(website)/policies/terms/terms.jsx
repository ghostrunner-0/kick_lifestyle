import React from 'react'

const terms = () => {
  return (
    <div>terms</div>
  )
}

export default terms