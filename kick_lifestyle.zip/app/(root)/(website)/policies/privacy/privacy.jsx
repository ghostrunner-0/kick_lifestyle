import React from 'react'

const privacy = () => {
  return (
    <div>privacy</div>
  )
}

export default privacy