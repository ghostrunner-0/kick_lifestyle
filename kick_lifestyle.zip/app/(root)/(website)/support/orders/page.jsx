import OrderClient from "./OrderClient";

// ✅ Tell Next.js this page must be rendered dynamically (no static build)
export const dynamic = "force-dynamic";

// ✅ Optional: skip caching completely (recommended for live order lookups)
export const revalidate = 0;

const BRAND = "KICK LIFESTYLE";
const BRAND_LONG = "Kick Lifestyle";
const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || "https://kick.com.np";
const PAGE_PATH = "/support/orders";
const PAGE_URL = `${SITE_URL}${PAGE_PATH}`;

const OG_IMAGE = `${SITE_URL}/meta-images/logo.png`;

// ✅ Move viewport outside metadata (Next.js requirement)
export const viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  viewportFit: "cover",
};

export const metadata = {
  metadataBase: new URL(SITE_URL),
  title: `Orders & Delivery | ${BRAND}`,
  description: `Track your order, view delivery timelines, and get shipping details for ${BRAND_LONG}.`,
  alternates: { canonical: PAGE_PATH },
  openGraph: {
    type: "website",
    url: PAGE_URL,
    siteName: BRAND_LONG,
    title: `Orders & Delivery | ${BRAND}`,
    description: `Track your order and learn how shipping works at ${BRAND_LONG}.`,
    images: [
      {
        url: OG_IMAGE,
        width: 1200,
        height: 630,
        alt: `${BRAND_LONG} — Orders & Delivery`,
      },
    ],
    locale: "en_NP",
    alternateLocale: ["ne_NP", "en_US"],
  },
  twitter: {
    card: "summary_large_image",
    title: `Orders & Delivery | ${BRAND}`,
    description: `Track orders, delivery timelines, and shipping FAQs at ${BRAND_LONG}.`,
    images: [OG_IMAGE],
  },
  robots: { index: true, follow: true },
};

export default function Page() {
  return (
    <div className="relative">
      {/* subtle bg wash */}
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute inset-x-0 top-0 h-[120px]" />
      </div>

      <div className="mx-auto max-w-5xl px-4 py-6">
        <OrderClient />
      </div>
    </div>
  );
}
