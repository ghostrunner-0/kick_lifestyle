// /app/api/product-variant/[id]/route.js
import { isAuthenticated } from "@/lib/Authentication";
import { connectDB } from "@/lib/DB";
import { catchError, response } from "@/lib/helperFunctions";
import ProductVariant from "@/models/ProductVariant.model";
import "@/models/Product.model"; // ensure Product is registered for populate
import { isValidObjectId } from "mongoose";

export async function GET(req, { params }) {
  try {
    const admin = await isAuthenticated("admin");
    if (!admin) return response(false, 403, "unauthorized");

    await connectDB();
    const param = await params;
    const { id } = param || {};
    if (!id) return response(false, 400, "Missing variant id/sku");

    // Match by ObjectId if valid; otherwise treat as SKU (case-insensitive via uppercasing)
    let match = { deletedAt: null };
    if (isValidObjectId(id)) {
      match._id = id;
    } else {
      match.sku = String(id).trim().toUpperCase();
    }

    const variant = await ProductVariant.findOne(match)
      .select(
        [
          "product",
          "variantName",
          "mrp",
          "specialPrice",
          "sku",
          "stock", // ✅ include variant stock
          "swatchImage",
          "productGallery",
          "createdAt",
          "updatedAt",
        ].join(" ")
      )
      .populate({
        path: "product",
        select: "_id name slug hasVariants stock", // ✅ include product-level flags/stock
        model: "Product",
      })
      .lean();

    if (!variant) {
      return response(false, 404, "Product variant not found");
    }

    return response(true, 200, "Product variant found", variant);
  } catch (error) {
    return catchError(error);
  }
}
