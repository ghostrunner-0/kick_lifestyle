import React from 'react'

const UploadMedia = () => {
  return (
    <div>UploadMedia</div>
  )
}

export default UploadMedia